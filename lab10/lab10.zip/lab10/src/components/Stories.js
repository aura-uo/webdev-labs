import React, {useState, useEffect} from 'react';

const Stories = () => {
    const [stories, setStories] = useState(null);

    useEffect(() => {
        // Your code here
      }, [stories]);

    if (!stories) {
        return (
            <div>Before Stories fetched from server</div>  
        );
    }
    return (
        <div>
            <div>List of Stories goes here...</div>
            {/*
            this.state.Stories.map(post => {
                return <Post post={post} key={'post-' + post.id} />
            }
            */}
        </div>
    );     
}

export default Stories;