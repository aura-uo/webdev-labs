import React from 'react';
import {getHeaders} from '../utils';

const postBookmark = (postId) => {
    fetch("/api/bookmarks/", {
                method: "POST",
                headers: getHeaders(),
                body: JSON.stringify({"post_id": postId})
            })
            .then(response => response.json())
            .then(data => console.log(data));
}

const removeBookmark = (bookmarkId) => {
    fetch(`/api/bookmarks/${bookmarkId}`, {
        method: "DELETE",
        headers: getHeaders()
    })
    .then(response => response.json())
    .then(data => console.log(data));
}

const BookmarkButton = ({bookmarkId, postId}) => {   
    const toggleBookmark = () => bookmarkId ? removeBookmark(bookmarkId) : postBookmark(postId);
    
    return(
        <button role="switch"
                className="bookmark" 
                aria-label="Bookmark Button" 
                aria-checked={bookmarkId ? true : false}
                onClick={toggleBookmark}
        >
            <i className={bookmarkId ? 'fas fa-bookmark' : 'far fa-bookmark'}></i>                        
        </button>
    )
};

export default BookmarkButton;