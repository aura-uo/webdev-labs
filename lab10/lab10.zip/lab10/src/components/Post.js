import React from "react";
import LikeButton from "./LikeButton";
import BookmarkButton from "./BookmarkButton";

const Post = ({post}) => {
    if (post) {
        return (
            <div className="card">
                <div className="header">
                    <h3>{ post.user.username }</h3>
                    <i className="fa fa-dots"></i>
                </div>
                <img 
                    alt={'Image posted by ' +  post.user.username } 
                    src={post.image_url}
                />
                <div className="info">
                        <div className="buttons">
                            <LikeButton 
                                likeId={post.current_user_like_id}
                                postId={post.id}
                            />
                            <BookmarkButton
                                bookmarkId={post.current_user_bookmark_id}
                                postId={post.id}
                            />
                        </div>
                        <p>{ post.caption }</p>
                    </div>
            </div>
        )
    } else {
        return <div>Loading...</div>;
    }
}

export default Post;