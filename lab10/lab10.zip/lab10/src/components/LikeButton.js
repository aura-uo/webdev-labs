import React from 'react';
import {getHeaders} from '../utils';

const postLike = (postId) => {
    fetch("/api/posts/likes/", {
                method: "POST",
                headers: getHeaders(),
                body: JSON.stringify({"post_id": postId})
            })
            .then(response => response.json())
            .then(data => console.log(data));
}

const removeLike = (likeId) => {
    fetch(`/api/posts/likes/${likeId}`, {
        method: "DELETE",
        headers: getHeaders()
    })
    .then(response => response.json())
    .then(data => console.log(data));
}

const LikeButton = ({likeId, postId}) => {   
    const toggleLike = () => likeId ? removeLike(likeId) : postLike(postId);
    
    return(
        <button role="switch"
                className="like" 
                aria-label="Like Button" 
                aria-checked={likeId ? true : false}
                onClick={toggleLike}
        >
            <i className={likeId ? 'fas fa-heart' : 'far fa-heart'}></i>                        
        </button>
    )
};

export default LikeButton;