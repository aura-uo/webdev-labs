import React, {useState, useEffect} from 'react';

const Suggestions = () => {
    const [suggestions, setSuggestions] = useState(null);

    useEffect(() => {
        // Your code here
      }, [suggestions]);

    if (!suggestions) {
        return (
            <div>Before Suggestions fetched from server</div>  
        );
    }
    return (
        <div>
            <div>List of Suggestions goes here...</div>
            {/*
            this.state.Suggestions.map(post => {
                return <Post post={post} key={'post-' + post.id} />
            }
            */}
        </div>
    );     
}

export default Suggestions;